// Timers & Alarms: a self-contained module, same isolation pattern as
// airdrop.js/schedule.js. Polls the server every second - timers are
// SERVER-authoritative (see lib/timers-store.js), so this page just
// reflects state rather than owning any countdown logic itself. That
// matters because the loud alarm beep happens on the server machine
// regardless of whether this page is even open.
(() => {
  const toastEl = document.getElementById('toast');
  let pollTimer = null;
  let audioCtx = null;

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  function showToast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toastEl.classList.remove('show'), 2600);
  }

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
      ...opts,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) throw new Error((data && data.error) || 'Something went wrong');
    return data;
  }

  function fmtRemaining(ms) {
    if (ms <= 0) return "0:00";
    const totalSec = Math.ceil(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  // A quick bonus beep IN THE BROWSER via Web Audio - handy if you're
  // actually looking at the page. The real, "loud through the system"
  // alarm is the server-side beep in lib/timers-store.js, which fires
  // regardless of whether anyone has this page open at all.
  function playBrowserBeep() {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.frequency.value = 880;
      osc.type = 'sine';
      gain.gain.value = 0.15;
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      setTimeout(() => osc.stop(), 250);
    } catch (e) { /* autoplay policies etc. - not critical, server beep is the real alarm */ }
  }

  function ringSvg(fracRemaining, ringing) {
    const r = 42;
    const c = 2 * Math.PI * r;
    const offset = c * (1 - fracRemaining);
    return `
      <svg viewBox="0 0 100 100" class="timer-ring">
        <circle cx="50" cy="50" r="${r}" class="timer-ring-track" />
        <circle cx="50" cy="50" r="${r}" class="timer-ring-progress${ringing ? ' ringing' : ''}"
          stroke-dasharray="${c}" stroke-dashoffset="${offset}" />
      </svg>
    `;
  }

  function renderCards(timers) {
    const wrap = document.getElementById('timers-list-wrap');
    if (!wrap) return;
    if (timers.length === 0) {
      wrap.innerHTML = `<div class="empty-state">No timers running. Add one above.</div>`;
      return;
    }
    wrap.innerHTML = `<div class="timers-grid">${timers.map((t) => {
      const frac = t.durationMs ? Math.max(0, Math.min(1, t.msRemaining / t.durationMs)) : 0;
      const ringing = t.status === 'ringing';
      return `
        <div class="timer-card${ringing ? ' ringing' : ''}" data-id="${t.id}">
          ${ringSvg(frac, ringing)}
          <div class="timer-card-inner">
            <div class="timer-remaining">${ringing ? '⏰' : fmtRemaining(t.msRemaining)}</div>
          </div>
          <div class="timer-label">${escapeHtml(t.label)}</div>
          <div class="timer-kind">${t.kind === 'alarm' ? '🔔 Alarm' : '⏱ Timer'}</div>
          ${ringing
            ? `<button class="btn timer-dismiss-btn" data-id="${t.id}">Dismiss</button>`
            : `<button class="del-btn timer-cancel-btn" data-id="${t.id}" title="Cancel">✕</button>`}
        </div>
      `;
    }).join('')}</div>`;

    wrap.querySelectorAll('.timer-dismiss-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await api(`/api/timers/${btn.dataset.id}/dismiss`, { method: 'POST' });
        poll();
      });
    });
    wrap.querySelectorAll('.timer-cancel-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await api(`/api/timers/${btn.dataset.id}`, { method: 'DELETE' });
        poll();
      });
    });
  }

  let lastRingingIds = new Set();
  async function poll() {
    try {
      const timers = await api('/api/timers');
      renderCards(timers);
      const nowRinging = new Set(timers.filter((t) => t.status === 'ringing').map((t) => t.id));
      // Only beep in-browser on the transition into ringing, not every poll.
      for (const id of nowRinging) {
        if (!lastRingingIds.has(id)) playBrowserBeep();
      }
      lastRingingIds = nowRinging;
    } catch (e) {
      const wrap = document.getElementById('timers-list-wrap');
      if (wrap) wrap.innerHTML = `<div class="empty-state">Could not load timers: ${escapeHtml(e.message)}</div>`;
    }
  }

  function render() {
    if (pollTimer) clearInterval(pollTimer);
    lastRingingIds = new Set();

    const crumbs = document.getElementById('crumbs');
    crumbs.innerHTML = '<span>Timers</span>';
    const view = document.getElementById('view');
    view.innerHTML = `
      <h1 class="page-title">Timers &amp; Alarms</h1>
      <div class="timers-page-sub">Up to 10 at once. When one goes off, this machine (the server) beeps loudly through its own speakers - not just this browser tab.</div>
      <div class="panel">
        <div class="timers-form-row">
          <input type="text" id="timer-label" placeholder="Label (e.g. Pomodoro, Study break)" maxlength="60" />
          <select id="timer-kind">
            <option value="timer">Timer</option>
            <option value="alarm">Alarm (at a time)</option>
          </select>
          <div id="timer-duration-fields" class="timer-duration-fields">
            <input type="number" id="timer-h" min="0" max="23" placeholder="hh" />
            <input type="number" id="timer-m" min="0" max="59" placeholder="mm" />
            <input type="number" id="timer-s" min="0" max="59" placeholder="ss" />
          </div>
          <input type="time" id="timer-alarm-time" class="timer-alarm-time" style="display:none;" />
          <button class="btn" id="timer-add-btn">Start</button>
        </div>
        <div id="timer-add-error"></div>
      </div>
      <div id="timers-list-wrap"><div class="empty-state">Loading…</div></div>
    `;

    const kindSelect = document.getElementById('timer-kind');
    const durationFields = document.getElementById('timer-duration-fields');
    const alarmField = document.getElementById('timer-alarm-time');
    kindSelect.addEventListener('change', () => {
      const isAlarm = kindSelect.value === 'alarm';
      durationFields.style.display = isAlarm ? 'none' : 'flex';
      alarmField.style.display = isAlarm ? 'block' : 'none';
    });

    document.getElementById('timer-add-btn').addEventListener('click', async () => {
      const label = document.getElementById('timer-label').value.trim();
      const kind = kindSelect.value;
      const errorBox = document.getElementById('timer-add-error');
      errorBox.innerHTML = '';
      const body = { label, kind };
      if (kind === 'alarm') {
        const t = alarmField.value;
        if (!t) { errorBox.innerHTML = `<div class="add-error">Pick a time for the alarm.</div>`; return; }
        body.targetTime = t;
      } else {
        const h = Number(document.getElementById('timer-h').value) || 0;
        const m = Number(document.getElementById('timer-m').value) || 0;
        const s = Number(document.getElementById('timer-s').value) || 0;
        const durationMs = (h * 3600 + m * 60 + s) * 1000;
        if (durationMs <= 0) { errorBox.innerHTML = `<div class="add-error">Enter a duration greater than zero.</div>`; return; }
        body.durationMs = durationMs;
      }
      try {
        await api('/api/timers', { method: 'POST', body });
        document.getElementById('timer-label').value = '';
        showToast('Started');
        poll();
      } catch (e) {
        errorBox.innerHTML = `<div class="add-error">${escapeHtml(e.message)}</div>`;
      }
    });

    poll();
    pollTimer = setInterval(poll, 1000);
  }

  window.Timers = { render };
})();
