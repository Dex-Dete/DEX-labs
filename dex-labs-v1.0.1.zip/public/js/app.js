(() => {
  const view = document.getElementById('view');
  const crumbs = document.getElementById('crumbs');
  const toastEl = document.getElementById('toast');
  document.getElementById('brand-home').addEventListener('click', () => { location.hash = '#/'; });
  document.getElementById('nav-lessons-btn').addEventListener('click', () => { location.hash = '#/'; });
  document.getElementById('nav-airdrop-btn').addEventListener('click', () => { location.hash = '#/airdrop'; });
  document.getElementById('nav-schedule-btn').addEventListener('click', () => { location.hash = '#/schedule'; });
  document.getElementById('nav-timers-btn').addEventListener('click', () => { location.hash = '#/timers'; });
  document.getElementById('server-info-btn').addEventListener('click', showServerInfo);

  const subsystemLabel = document.getElementById('subsystem-label');
  const navLessonsBtn = document.getElementById('nav-lessons-btn');
  const navAirdropBtn = document.getElementById('nav-airdrop-btn');
  const navScheduleBtn = document.getElementById('nav-schedule-btn');
  const navTimersBtn = document.getElementById('nav-timers-btn');
  // Every DEX Labs subsystem calls this so the top bar always shows
  // which one you're currently in.
  window.setSubsystem = function setSubsystem(name) {
    subsystemLabel.textContent = name;
    navLessonsBtn.classList.toggle('active', name === 'Lesson Tracker');
    navAirdropBtn.classList.toggle('active', name === 'AirDrop');
    navScheduleBtn.classList.toggle('active', name === 'Daily Schedule');
    navTimersBtn.classList.toggle('active', name === 'Timers');
  };

  const TAB_COLORS = ['#c0392b', '#d9a32b', '#3b7a57', '#4a6fa5', '#8e5aa8', '#c76b3e'];
  function colorFor(id) {
    let h = 0;
    for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
    return TAB_COLORS[h % TAB_COLORS.length];
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  function showToast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => toastEl.classList.remove('show'), 2600);
  }

  // Generic overlay modal, used for the lesson "Details" view. Closes on
  // backdrop click, the × button, or Escape.
  function showModal(titleHtml, bodyHtml) {
    let overlay = document.getElementById('modal-overlay');
    if (overlay) overlay.remove();
    overlay = document.createElement('div');
    overlay.id = 'modal-overlay';
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-box">
        <div class="modal-header">
          <div class="modal-title">${titleHtml}</div>
          <button class="modal-close" id="modal-close-btn">✕</button>
        </div>
        <div class="modal-body">${bodyHtml}</div>
      </div>
    `;
    document.body.appendChild(overlay);
    function close() { overlay.remove(); document.removeEventListener('keydown', onKey); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
    overlay.querySelector('#modal-close-btn').addEventListener('click', close);
    document.addEventListener('keydown', onKey);
    return { close };
  }

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
      ...opts,
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    let data = null;
    try { data = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) throw new Error((data && data.error) || 'Something went wrong');
    return data;
  }

  function uploadFiles(subjectId, files, onProgress) {
    return new Promise((resolve, reject) => {
      const form = new FormData();
      for (const f of files) form.append('files', f);
      const xhr = new XMLHttpRequest();
      xhr.open('POST', `/api/subjects/${subjectId}/tutes`);
      xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) onProgress(e.loaded / e.total);
      };
      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(JSON.parse(xhr.responseText));
        } else {
          let msg = 'Upload failed';
          try { msg = JSON.parse(xhr.responseText).error || msg; } catch (e) {}
          reject(new Error(msg));
        }
      };
      xhr.onerror = () => reject(new Error('Upload failed - check your connection'));
      xhr.send(form);
    });
  }

  function fmtSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    const units = ['KB', 'MB', 'GB', 'TB'];
    let i = -1;
    do { bytes /= 1024; i++; } while (bytes >= 1024 && i < units.length - 1);
    return bytes.toFixed(bytes >= 10 ? 0 : 1) + ' ' + units[i];
  }

  function extBadge(name) {
    const ext = (name.split('.').pop() || '?').toUpperCase().slice(0, 4);
    return ext;
  }

  async function showServerInfo() {
    try {
      const info = await api('/api/server-info');
      const lines = info.addresses.length
        ? info.addresses.map((a) => `http://${a}:${info.port}`).join('\n')
        : 'No LAN address detected - check your WiFi connection.';
      alert('Open this on any phone/PC on the same WiFi:\n\n' + lines);
    } catch (e) {
      alert('Could not read server info.');
    }
  }

  // Shows the running server's version at the bottom of every page - if
  // this doesn't match what you expect after an update, your browser is
  // showing a cached copy of the page; hard-refresh (Ctrl+Shift+R) to fix.
  (async () => {
    try {
      const info = await api('/api/server-info');
      document.getElementById('build-footer').textContent = `DEX Labs v${info.version}`;
    } catch (e) { /* not critical */ }
  })();

  // ---------------- Router ----------------
  window.addEventListener('hashchange', route);
  window.addEventListener('DOMContentLoaded', route);

  function parseHash() {
    const h = location.hash.replace(/^#\/?/, '');
    return h.split('/').filter(Boolean);
  }

  async function route() {
    const parts = parseHash();
    try {
      if (parts.length === 0) { window.setSubsystem('Lesson Tracker'); return renderSubjects(); }
      // AirDrop, Daily Schedule, and Timers are separate feature modules
      // (see /js/airdrop.js, /js/schedule.js, /js/timers.js) - we just
      // forward to them here rather than reimplementing anything of
      // their own.
      if (parts[0] === 'airdrop') { window.setSubsystem('AirDrop'); return window.Airdrop.render(); }
      if (parts[0] === 'schedule') { window.setSubsystem('Daily Schedule'); return window.Schedule.render(); }
      if (parts[0] === 'timers') { window.setSubsystem('Timers'); return window.Timers.render(); }
      window.setSubsystem('Lesson Tracker');
      if (parts[0] === 'subject' && parts[1] && !parts[2]) return renderSubjectHome(parts[1]);
      if (parts[0] === 'subject' && parts[1] === undefined) return renderSubjects();
      if (parts[0] === 'subject' && parts[2] === 'grade' && !parts[3]) return renderGradeChoice(parts[1]);
      if (parts[0] === 'subject' && parts[2] === 'grade' && parts[3]) return renderLessons(parts[1], parts[3]);
      if (parts[0] === 'subject' && parts[2] === 'tutes') return renderTutes(parts[1]);
      renderSubjects();
    } catch (e) {
      view.innerHTML = `<div class="empty-state">Something went wrong: ${escapeHtml(e.message)}</div>`;
    }
  }

  function setCrumbs(items) {
    crumbs.innerHTML = items
      .map((it, i) => (i === items.length - 1
        ? `<span>${escapeHtml(it.label)}</span>`
        : `<a data-href="${it.href}">${escapeHtml(it.label)}</a> &nbsp;/&nbsp; `))
      .join('');
    crumbs.querySelectorAll('a').forEach((a) => {
      a.addEventListener('click', () => { location.hash = a.dataset.href; });
    });
  }

  // ---------------- Views ----------------
  async function renderSubjects() {
    setCrumbs([{ label: 'Subjects', href: '#/' }]);
    view.innerHTML = `<h1 class="page-title">Your Subjects</h1><div class="grid" id="subj-grid"><div class="empty-state">Loading…</div></div>`;
    const subjects = await api('/api/subjects');
    const grid = document.getElementById('subj-grid');
    grid.innerHTML = subjects.map((s) => `
      <div class="subject-card" style="--tab-color:${colorFor(s.id)}" data-id="${s.id}">
        <h3>${escapeHtml(s.name)}</h3>
        <div class="meta">Grades &amp; Tutes</div>
      </div>
    `).join('') + `<div class="add-card" id="add-subject-card">+ Add subject</div>`;

    grid.querySelectorAll('.subject-card').forEach((card) => {
      card.addEventListener('click', () => { location.hash = `#/subject/${card.dataset.id}`; });
    });
    document.getElementById('add-subject-card').addEventListener('click', async () => {
      const name = prompt('New subject name:');
      if (!name || !name.trim()) return;
      try {
        await api('/api/subjects', { method: 'POST', body: { name: name.trim() } });
        showToast('Subject added');
        renderSubjects();
      } catch (e) { showToast(e.message); }
    });
  }

  async function renderSubjectHome(subjectId) {
    const subjects = await api('/api/subjects');
    const subject = subjects.find((s) => s.id === subjectId);
    if (!subject) { location.hash = '#/'; return; }
    setCrumbs([{ label: 'Subjects', href: '#/' }, { label: subject.name, href: `#/subject/${subjectId}` }]);
    view.innerHTML = `
      <h1 class="page-title">${escapeHtml(subject.name)}</h1>
      <div class="choice-row">
        <div class="choice-tile grade10" id="tile-grades">
          <div class="big-label">Grades</div>
          <div class="desc">Recorded YouTube lessons, by grade</div>
        </div>
        <div class="choice-tile" id="tile-tutes">
          <div class="big-label">📄 Tutes</div>
          <div class="desc">PDF, ZIP and other files (up to 5GB each)</div>
        </div>
      </div>
    `;
    document.getElementById('tile-grades').addEventListener('click', () => { location.hash = `#/subject/${subjectId}/grade`; });
    document.getElementById('tile-tutes').addEventListener('click', () => { location.hash = `#/subject/${subjectId}/tutes`; });
  }

  async function renderGradeChoice(subjectId) {
    const subjects = await api('/api/subjects');
    const subject = subjects.find((s) => s.id === subjectId);
    if (!subject) { location.hash = '#/'; return; }
    const categories = subject.categories || [];
    setCrumbs([
      { label: 'Subjects', href: '#/' },
      { label: subject.name, href: `#/subject/${subjectId}` },
      { label: 'Grades', href: `#/subject/${subjectId}/grade` },
    ]);
    view.innerHTML = `
      <h1 class="page-title">${escapeHtml(subject.name)} — Choose a category</h1>
      <div class="hint" style="margin-bottom:10px;">Double-click a category to rename it (e.g. change "Grade 10" to "Revision"). Use ✕ to delete an empty category.</div>
      <div class="choice-row category-row">
        ${categories.map((c) => `
          <div class="choice-tile category-tile" data-id="${c.id}">
            <button class="category-del-btn" title="Delete category" data-id="${c.id}">✕</button>
            <div class="big-label" data-role="label">${escapeHtml(c.name)}</div>
            <div class="desc">View / add lessons</div>
          </div>
        `).join('')}
        <div class="choice-tile add-category-tile" id="add-category-tile">
          <div class="big-label">+ Add category</div>
          <div class="desc">e.g. Revision, Extra Practice</div>
        </div>
      </div>
    `;

    view.querySelectorAll('.category-tile').forEach((tile) => {
      const catId = tile.dataset.id;
      tile.addEventListener('click', (e) => {
        if (e.target.closest('[data-role="label"]') && tile.classList.contains('editing')) return;
        if (e.target.closest('.category-del-btn')) return;
        location.hash = `#/subject/${subjectId}/grade/${catId}`;
      });
      const label = tile.querySelector('[data-role="label"]');
      label.addEventListener('dblclick', async (e) => {
        e.stopPropagation();
        const current = categories.find((c) => c.id === catId);
        const name = prompt('Rename category:', current ? current.name : '');
        if (!name || !name.trim()) return;
        try {
          await api(`/api/subjects/${subjectId}/categories/${catId}`, { method: 'PATCH', body: { name: name.trim() } });
          renderGradeChoice(subjectId);
        } catch (err) {
          showToast(err.message);
        }
      });
    });

    view.querySelectorAll('.category-del-btn').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const catId = btn.dataset.id;
        const current = categories.find((c) => c.id === catId);
        if (!confirm(`Delete category "${current ? current.name : catId}"? This only works if it has no lessons in it.`)) return;
        try {
          await api(`/api/subjects/${subjectId}/categories/${catId}`, { method: 'DELETE' });
          renderGradeChoice(subjectId);
        } catch (err) {
          showToast(err.message);
        }
      });
    });

    document.getElementById('add-category-tile').addEventListener('click', async () => {
      const name = prompt('New category name (e.g. "Revision", "Grade 12"):');
      if (!name || !name.trim()) return;
      try {
        await api(`/api/subjects/${subjectId}/categories`, { method: 'POST', body: { name: name.trim() } });
        renderGradeChoice(subjectId);
      } catch (err) {
        showToast(err.message);
      }
    });
  }

  async function renderLessons(subjectId, grade) {
    const subjects = await api('/api/subjects');
    const subject = subjects.find((s) => s.id === subjectId);
    if (!subject) { location.hash = '#/'; return; }
    const category = (subject.categories || []).find((c) => c.id === grade);
    const categoryName = category ? category.name : grade;
    setCrumbs([
      { label: 'Subjects', href: '#/' },
      { label: subject.name, href: `#/subject/${subjectId}` },
      { label: 'Grades', href: `#/subject/${subjectId}/grade` },
      { label: categoryName, href: `#/subject/${subjectId}/grade/${grade}` },
    ]);
    view.innerHTML = `
      <h1 class="page-title">${escapeHtml(subject.name)} — ${escapeHtml(categoryName)}</h1>
      <div class="panel">
        <div class="form-row">
          <input type="url" id="yt-url" placeholder="Paste a YouTube video or playlist link" />
          <button class="btn" id="yt-add-btn">Add</button>
        </div>
        <div class="hint">Pasting a playlist link automatically adds every video in it.</div>
        <div id="yt-add-error"></div>
      </div>
      <div id="lessons-wrap"><div class="empty-state">Loading…</div></div>
    `;

    async function loadLessons() {
      const lessons = await api(`/api/subjects/${subjectId}/lessons?grade=${grade}`);
      const wrap = document.getElementById('lessons-wrap');
      if (lessons.length === 0) {
        wrap.innerHTML = `<div class="empty-state">No lessons yet. Paste a YouTube link above to add the first one.</div>`;
        return;
      }
      const watchedCount = lessons.filter((l) => l.watched).length;
      wrap.innerHTML = `
        <div class="watch-progress">${watchedCount} of ${lessons.length} watched</div>
        <div class="lesson-list">${lessons.map((l) => `
        <div class="lesson-item${l.watched ? ' watched' : ''}" data-id="${l.id}">
          <div class="thumb-wrap" data-id="${l.id}" title="Click to mark as ${l.watched ? 'unwatched' : 'watched'}">
            <img src="${l.thumbnail || ''}" alt="" loading="lazy" onerror="this.style.visibility='hidden'"/>
            <span class="watched-badge">✓ Watched</span>
          </div>
          <div class="info">
            <a href="${escapeHtml(l.url)}" target="_blank" rel="noopener">${escapeHtml(l.title)}</a>
            ${l.playlistTitle ? `<span class="tag">${escapeHtml(l.playlistTitle)}</span>` : ''}
          </div>
          <button class="info-btn" title="View full title and description" data-id="${l.id}">ⓘ</button>
          <button class="del-btn" title="Remove" data-id="${l.id}">✕</button>
        </div>
      `).join('')}</div>`;
      wrap.querySelectorAll('.del-btn').forEach((btn) => {
        btn.addEventListener('click', async () => {
          if (!confirm('Remove this lesson?')) return;
          await api(`/api/lessons/${btn.dataset.id}`, { method: 'DELETE' });
          loadLessons();
        });
      });
      wrap.querySelectorAll('.info-btn').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const lesson = lessons.find((l) => l.id === btn.dataset.id);
          const modal = showModal('Loading…', '<div class="empty-state">Fetching details from YouTube…</div>');
          try {
            const details = await api(`/api/lessons/${btn.dataset.id}/details`);
            modal.close();
            showModal(
              escapeHtml(details.title || lesson.title),
              `<p class="modal-description">${escapeHtml(details.description).replace(/\n/g, '<br>')}</p>
               <a class="btn" href="${escapeHtml(lesson.url)}" target="_blank" rel="noopener" style="display:inline-block;margin-top:10px;text-decoration:none;">Open on YouTube</a>`
            );
          } catch (e) {
            modal.close();
            showModal(escapeHtml(lesson.title), `<p class="modal-description">${escapeHtml(e.message)}</p>`);
          }
        });
      });
      wrap.querySelectorAll('.thumb-wrap').forEach((thumb) => {
        thumb.addEventListener('click', async () => {
          const item = thumb.closest('.lesson-item');
          const nowWatched = !item.classList.contains('watched');
          // Optimistic UI - flip it instantly, then confirm with the server.
          item.classList.toggle('watched', nowWatched);
          try {
            await api(`/api/lessons/${thumb.dataset.id}/watched`, { method: 'PATCH', body: { watched: nowWatched } });
            loadLessons();
          } catch (e) {
            item.classList.toggle('watched', !nowWatched); // revert on failure
            showToast(e.message);
          }
        });
      });
    }
    loadLessons();

    document.getElementById('yt-add-btn').addEventListener('click', async () => {
      const input = document.getElementById('yt-url');
      const url = input.value.trim();
      const errorBox = document.getElementById('yt-add-error');
      errorBox.innerHTML = '';
      if (!url) return;
      const btn = document.getElementById('yt-add-btn');
      btn.disabled = true;
      btn.innerHTML = `<span class="spinner"></span>Adding…`;
      try {
        const result = await api(`/api/subjects/${subjectId}/lessons`, { method: 'POST', body: { grade, url } });
        showToast(`Added ${result.added.length} lesson${result.added.length > 1 ? 's' : ''}`);
        if (result.warning) {
          errorBox.innerHTML = `<div class="add-error add-warning">${escapeHtml(result.warning)}</div>`;
        }
        input.value = '';
        loadLessons();
      } catch (e) {
        // Persistent, not a fleeting toast - playlist failures especially
        // need a message you can actually read and act on (or copy to me).
        errorBox.innerHTML = `<div class="add-error">${escapeHtml(e.message)}</div>`;
      } finally {
        btn.disabled = false;
        btn.textContent = 'Add';
      }
    });
  }

  async function renderTutes(subjectId) {
    const subjects = await api('/api/subjects');
    const subject = subjects.find((s) => s.id === subjectId);
    if (!subject) { location.hash = '#/'; return; }
    setCrumbs([
      { label: 'Subjects', href: '#/' },
      { label: subject.name, href: `#/subject/${subjectId}` },
      { label: 'Tutes', href: `#/subject/${subjectId}/tutes` },
    ]);
    view.innerHTML = `
      <h1 class="page-title">${escapeHtml(subject.name)} — Tutes</h1>
      <div class="panel">
        <div class="dropzone" id="dropzone">
          Tap to choose files, or drag &amp; drop here<br/>
          <span class="hint">PDF, ZIP, or any file type — up to 5GB each</span>
        </div>
        <input type="file" id="file-input" multiple style="display:none" />
        <div id="upload-status"></div>
      </div>
      <div id="tutes-wrap"><div class="empty-state">Loading…</div></div>
    `;

    async function loadTutes() {
      const tutes = await api(`/api/subjects/${subjectId}/tutes`);
      const wrap = document.getElementById('tutes-wrap');
      if (tutes.length === 0) {
        wrap.innerHTML = `<div class="empty-state">No files yet. Add a tute above.</div>`;
        return;
      }
      wrap.innerHTML = `<div class="file-list">${tutes.map((t) => `
        <div class="file-item" data-id="${t.id}">
          <div class="ficon">${escapeHtml(extBadge(t.originalName))}</div>
          <div class="info">
            <div class="name">${escapeHtml(t.originalName)}</div>
            <div class="size">${fmtSize(t.size)}</div>
          </div>
          <a class="dl" href="/api/tutes/${t.id}/download" download>Download</a>
          <button class="del-btn" title="Delete" data-id="${t.id}">✕</button>
        </div>
      `).join('')}</div>`;
      wrap.querySelectorAll('.del-btn').forEach((btn) => {
        btn.addEventListener('click', async () => {
          if (!confirm('Delete this file? This cannot be undone.')) return;
          await api(`/api/tutes/${btn.dataset.id}`, { method: 'DELETE' });
          loadTutes();
        });
      });
    }
    loadTutes();

    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('file-input');
    const statusEl = document.getElementById('upload-status');

    dropzone.addEventListener('click', () => fileInput.click());
    ['dragover', 'dragenter'].forEach((ev) => dropzone.addEventListener(ev, (e) => {
      e.preventDefault(); dropzone.classList.add('drag');
    }));
    ['dragleave', 'dragend', 'drop'].forEach((ev) => dropzone.addEventListener(ev, () => {
      dropzone.classList.remove('drag');
    }));
    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      if (e.dataTransfer.files && e.dataTransfer.files.length) startUpload(e.dataTransfer.files);
    });
    fileInput.addEventListener('change', () => {
      if (fileInput.files.length) startUpload(fileInput.files);
    });

    function startUpload(fileList) {
      const files = Array.from(fileList);
      const totalSize = files.reduce((a, f) => a + f.size, 0);
      statusEl.innerHTML = `
        <div class="upload-row">Uploading ${files.length} file${files.length > 1 ? 's' : ''} (${fmtSize(totalSize)})…</div>
        <div class="progress-wrap"><div class="progress-bar" id="pbar"></div></div>
      `;
      const pbar = document.getElementById('pbar');
      uploadFiles(subjectId, files, (frac) => { pbar.style.width = `${Math.round(frac * 100)}%`; })
        .then(() => {
          statusEl.innerHTML = '';
          showToast('Uploaded');
          fileInput.value = '';
          loadTutes();
        })
        .catch((e) => {
          statusEl.innerHTML = `<div class="upload-row">${escapeHtml(e.message)}</div>`;
        });
    }
  }
})();
