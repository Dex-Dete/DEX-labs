# DEX Labs tray app - the actual application now (this IS what gets
# launched by the Desktop/Start Menu shortcuts and auto-start).
#
# Architecture note (v0.2.2 stability rewrite): earlier versions showed/
# hid this script's OWN console window for the "Console" feature. That
# was the root cause of the "tray won't close / closes unexpectedly"
# problem: if you close a console window via its native [X] button
# (rather than our menu), Windows terminates the WHOLE process hosting
# it - which was this tray app itself, taking the server down with it,
# unpredictably. Fixed by never showing this process's own console at
# all. Instead, "Console" opens a completely separate, disposable
# PowerShell window that just tails logs.txt - closing THAT window has
# zero effect on the tray or the server, by construction, because it's
# a different process entirely.
#
# Built with PowerShell + built-in .NET (WinForms/Drawing), NOT an npm
# tray package - avoids adding another native/compiled dependency that
# could fail to install (see: the whole @distube/ytpl saga).

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName Microsoft.VisualBasic

$AppRoot = $PSScriptRoot
Set-Location $AppRoot
$LogPath = Join-Path $AppRoot "logs.txt"

function Write-DexLog($msg) {
  try { Add-Content -Path $LogPath -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg" -ErrorAction SilentlyContinue } catch {}
}

# Hide this process's own console immediately and permanently - see note
# above for why this is never shown again.
Add-Type -Name Win32Console -Namespace DexLabs -MemberDefinition '
  [DllImport("Kernel32.dll")]
  public static extern IntPtr GetConsoleWindow();
  [DllImport("user32.dll")]
  public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
'
try {
  $consoleHandle = [DexLabs.Win32Console]::GetConsoleWindow()
  [DexLabs.Win32Console]::ShowWindow($consoleHandle, 0) | Out-Null # 0 = SW_HIDE
} catch {}

# Everything else is wrapped in one top-level try/catch so an unexpected
# error becomes a visible message + a logs.txt entry instead of the tray
# app just silently vanishing with no clue why.
try {

# ---------- config (port, etc.) ----------
function Get-DexConfig {
  $configPath = Join-Path $AppRoot "data\config.json"
  $default = @{ port = 3002 }
  try {
    if (Test-Path $configPath) {
      $loaded = Get-Content $configPath -Raw | ConvertFrom-Json
      if ($loaded.port) { return @{ port = [int]$loaded.port } }
    }
  } catch {}
  return $default
}
function Set-DexConfigPort([int]$NewPort) {
  $dataDir = Join-Path $AppRoot "data"
  if (-not (Test-Path $dataDir)) { New-Item -ItemType Directory -Path $dataDir -Force | Out-Null }
  $configPath = Join-Path $dataDir "config.json"
  $current = @{}
  try {
    if (Test-Path $configPath) { $current = Get-Content $configPath -Raw | ConvertFrom-Json }
  } catch {}
  $obj = @{}
  if ($current.PSObject -and $current.PSObject.Properties) {
    foreach ($p in $current.PSObject.Properties) { $obj[$p.Name] = $p.Value }
  }
  $obj.port = $NewPort
  ($obj | ConvertTo-Json) | Set-Content -Path $configPath -Encoding UTF8
}

# ---------- version ----------
function Get-CurrentVersion {
  try {
    $pkg = Get-Content (Join-Path $AppRoot "package.json") -Raw | ConvertFrom-Json
    return $pkg.version
  } catch {
    return "0.0.0"
  }
}
$CurrentVersion = Get-CurrentVersion
$DisplayLabel = "DEX Labs v$CurrentVersion"

# ---------- tray icon (generated once, cached to disk) ----------
$IconPath = Join-Path $AppRoot "tray-icon.ico"
. (Join-Path $AppRoot "generate-icon.ps1")
if (-not (Test-Path $IconPath)) {
  try { New-DexTrayIcon -Path $IconPath } catch { Write-DexLog "Could not generate tray icon: $_" }
}

# ---------- kill anything already running (port + name-scoped) ----------
# This is the "kill node" behavior explicitly wanted for BOTH startup and
# exit: never leaves a stale/duplicate server process behind. Scoped to
# (a) whatever port is currently configured, and (b) node processes whose
# command line mentions server.js - deliberately NOT a blanket
# `taskkill /IM node.exe`, which would also kill unrelated Node
# applications the user might have running for other things.
function Clear-DexNodeProcess {
  $cfg = Get-DexConfig
  $port = $cfg.port
  try {
    $lines = netstat -ano | Select-String ":$port " | Select-String "LISTENING"
    foreach ($line in $lines) {
      $parts = ($line.ToString() -split '\s+') | Where-Object { $_ -ne '' }
      Stop-Process -Id $parts[-1] -Force -ErrorAction SilentlyContinue
    }
  } catch {}
  try {
    Get-CimInstance Win32_Process -Filter "Name='node.exe'" -ErrorAction SilentlyContinue |
      Where-Object { $_.CommandLine -like '*server.js*' } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  } catch {}
  Start-Sleep -Milliseconds 300 # give the OS a moment to actually release the port
}

function Clear-DuplicateTrayInstances {
  try {
    $myPid = $PID
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
      Where-Object { $_.CommandLine -like '*tray.ps1*' -and $_.ProcessId -ne $myPid } |
      ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  } catch {}
}

# ---------- server child process management ----------
$script:ServerProcess = $null
$script:OutputSubs = @()
$script:CurrentPort = (Get-DexConfig).port

function Start-DexServer {
  Clear-DexNodeProcess
  $cfg = Get-DexConfig
  $script:CurrentPort = $cfg.port

  $psi = New-Object System.Diagnostics.ProcessStartInfo
  $psi.FileName = "node"
  $psi.Arguments = "server.js"
  $psi.WorkingDirectory = $AppRoot
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.EnvironmentVariables["PORT"] = "$($cfg.port)"

  $proc = New-Object System.Diagnostics.Process
  $proc.StartInfo = $psi
  $proc.EnableRaisingEvents = $true

  $handler = {
    if ($null -ne $Event.SourceEventArgs.Data) {
      $logPath = $Event.MessageData
      try { Add-Content -Path $logPath -Value $Event.SourceEventArgs.Data -ErrorAction SilentlyContinue } catch {}
    }
  }
  $script:OutputSubs += Register-ObjectEvent -InputObject $proc -EventName OutputDataReceived -Action $handler -MessageData $LogPath
  $script:OutputSubs += Register-ObjectEvent -InputObject $proc -EventName ErrorDataReceived -Action $handler -MessageData $LogPath

  $proc.Start() | Out-Null
  $proc.BeginOutputReadLine()
  $proc.BeginErrorReadLine()
  $script:ServerProcess = $proc
  Write-DexLog "=== DEX Labs server started (PID $($proc.Id), port $($cfg.port)) ==="
  if ($notifyIcon) { $notifyIcon.Text = "$DisplayLabel (port $($cfg.port))" }
}

function Stop-DexServer {
  foreach ($sub in $script:OutputSubs) {
    try { Unregister-Event -SourceIdentifier $sub.Name -ErrorAction SilentlyContinue } catch {}
  }
  $script:OutputSubs = @()
  if ($script:ServerProcess -and -not $script:ServerProcess.HasExited) {
    try { $script:ServerProcess.Kill() } catch {}
  }
  Clear-DexNodeProcess
  $script:ServerProcess = $null
  Write-DexLog "=== DEX Labs server stopped ==="
}

# ---------- disposable console/log viewer (separate process, on purpose) ----------
$script:ConsoleViewerProcess = $null
function Show-DexConsoleViewer {
  if ($script:ConsoleViewerProcess -and -not $script:ConsoleViewerProcess.HasExited) {
    return # already open - closing/reopening is the user's call, don't spawn a duplicate
  }
  # Built and passed via -EncodedCommand (base64) rather than a quoted
  # -Command string - this was the actual bug: Start-Process -ArgumentList
  # mangles manually-embedded quotes when the underlying path contains a
  # space (very common - e.g. "C:\Users\name\Documents\DEX labs"), which
  # broke Get-Content's -Path argument. Encoding the whole script sidesteps
  # shell-quoting entirely, regardless of what's in the path.
  $scriptText = @"
Write-Host 'DEX Labs Console - this window is separate from the app.'
Write-Host 'Closing it does NOT stop the server. Live output below:'
Write-Host '========================================'
Get-Content -Path '$LogPath' -Wait -Tail 80
"@
  $encodedCommand = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($scriptText))
  try {
    $script:ConsoleViewerProcess = Start-Process -FilePath "powershell.exe" `
      -ArgumentList @("-NoProfile", "-NoExit", "-EncodedCommand", $encodedCommand) -PassThru
  } catch {
    [System.Windows.Forms.MessageBox]::Show("Could not open the console window: $_", "DEX Labs", 0, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
  }
}

Clear-DuplicateTrayInstances
Start-DexServer

# ---------- version comparison ----------
function Test-VersionNewer($NewVersion, $CurrentVer) {
  $n = @($NewVersion -split '\.' | ForEach-Object { [int]$_ })
  $c = @($CurrentVer -split '\.' | ForEach-Object { [int]$_ })
  $len = [Math]::Max($n.Count, $c.Count)
  for ($i = 0; $i -lt $len; $i++) {
    $nv = if ($i -lt $n.Count) { $n[$i] } else { 0 }
    $cv = if ($i -lt $c.Count) { $c[$i] } else { 0 }
    if ($nv -gt $cv) { return $true }
    if ($nv -lt $cv) { return $false }
  }
  return $false
}

# ---------- tray icon + menu ----------
$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
if (Test-Path $IconPath) {
  $notifyIcon.Icon = New-Object System.Drawing.Icon($IconPath)
} else {
  $notifyIcon.Icon = [System.Drawing.SystemIcons]::Application
}
$notifyIcon.Text = "$DisplayLabel (port $($script:CurrentPort))"
$notifyIcon.Visible = $true

$contextMenu = New-Object System.Windows.Forms.ContextMenuStrip
$menuOpen = $contextMenu.Items.Add("Open DEX Labs")
$contextMenu.Items.Add("-") | Out-Null
$menuConsole = $contextMenu.Items.Add("Console")
$menuUpdate = $contextMenu.Items.Add("Update")
$menuSettings = $contextMenu.Items.Add("Settings")
$menuOpenFolder = $contextMenu.Items.Add("Open App Folder")
$contextMenu.Items.Add("-") | Out-Null
$menuVersion = $contextMenu.Items.Add($DisplayLabel)
$menuVersion.Enabled = $false
$contextMenu.Items.Add("-") | Out-Null
$menuExit = $contextMenu.Items.Add("Exit")
$notifyIcon.ContextMenuStrip = $contextMenu

function Open-DexInBrowser {
  try { Start-Process "http://localhost:$($script:CurrentPort)" } catch {}
}
function Open-DexAppFolder {
  try { Start-Process "explorer.exe" -ArgumentList $AppRoot } catch {}
}

# Left-click does the thing you'd actually want most often - see the
# site. Console/Update/Settings/Exit stay in the right-click menu since
# they're less frequent, more deliberate actions.
$menuOpen.Add_Click({ Open-DexInBrowser })
$notifyIcon.Add_MouseClick({
  param($sender, $e)
  if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Left) { Open-DexInBrowser }
})
$menuConsole.Add_Click({ Show-DexConsoleViewer })
$menuOpenFolder.Add_Click({ Open-DexAppFolder })

$menuUpdate.Add_Click({
  $ofd = New-Object System.Windows.Forms.OpenFileDialog
  $ofd.Filter = "DEX Labs update (*.zip)|*.zip"
  $ofd.Title = "Select a DEX Labs update file"
  if ($ofd.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
  $zipPath = $ofd.FileName

  $currentVer = Get-CurrentVersion
  $newVer = $null
  try {
    $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    $pkgEntry = $zip.Entries | Where-Object { $_.FullName -eq "package.json" } | Select-Object -First 1
    if (-not $pkgEntry) {
      $zip.Dispose()
      [System.Windows.Forms.MessageBox]::Show("That zip doesn't look like a DEX Labs update - no package.json found at its root.", "Update failed", 0, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
      return
    }
    $reader = New-Object System.IO.StreamReader($pkgEntry.Open())
    $newPkgText = $reader.ReadToEnd()
    $reader.Close()
    $zip.Dispose()
    $newPkg = $newPkgText | ConvertFrom-Json
    $newVer = $newPkg.version
  } catch {
    [System.Windows.Forms.MessageBox]::Show("Could not read that update file: $_", "Update failed", 0, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    return
  }

  if (-not (Test-VersionNewer -NewVersion $newVer -CurrentVer $currentVer)) {
    [System.Windows.Forms.MessageBox]::Show("Selected update (v$newVer) is not newer than the currently installed version (v$currentVer). Update cancelled.", "Update cancelled", 0, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
    return
  }

  $confirm = [System.Windows.Forms.MessageBox]::Show(
    "Update from v$currentVer to v$newVer?`n`nYour lessons, tutes, AirDrop files, schedule, timers, and settings will be backed up automatically before anything changes. The server will restart when it's done.",
    "Confirm update", [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question
  )
  if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) { return }

  Write-DexLog "=== Applying update: v$currentVer -> v$newVer ==="
  Stop-DexServer

  $applyScript = Join-Path $AppRoot "apply-update.ps1"
  & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $applyScript -ZipPath $zipPath *>&1 | ForEach-Object {
    try { Add-Content -Path $LogPath -Value $_ -ErrorAction SilentlyContinue } catch {}
  }
  $updateExitCode = $LASTEXITCODE

  Start-DexServer

  if ($updateExitCode -eq 0) {
    [System.Windows.Forms.MessageBox]::Show("Updated to v$newVer. Server restarted.`n`nA backup of your previous data is in the 'backups' folder.", "Update complete", 0, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
  } else {
    [System.Windows.Forms.MessageBox]::Show("The update ran into a problem - click Console to see details. Your data was backed up before anything changed - check the 'backups' folder if anything looks wrong. The server has been restarted with whatever is currently on disk.", "Update finished with warnings", 0, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
  }
})

$menuSettings.Add_Click({
  $cfg = Get-DexConfig
  $portInput = [Microsoft.VisualBasic.Interaction]::InputBox(
    "Port DEX Labs runs on (1024-65535).`n`nYou'll need to update any bookmarks/shortcuts on other devices to match after changing this.",
    "DEX Labs Settings", "$($cfg.port)"
  )
  if ([string]::IsNullOrWhiteSpace($portInput)) { return }
  $newPort = 0
  if (-not [int]::TryParse($portInput.Trim(), [ref]$newPort) -or $newPort -lt 1024 -or $newPort -gt 65535) {
    [System.Windows.Forms.MessageBox]::Show("That's not a valid port - use a number between 1024 and 65535.", "Invalid port", 0, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
    return
  }
  if ($newPort -eq $cfg.port) { return }

  Set-DexConfigPort -NewPort $newPort
  Write-DexLog "=== Port changed: $($cfg.port) -> $newPort ==="
  Stop-DexServer
  Start-DexServer

  # Best-effort firewall rule update - may silently no-op if this process
  # isn't running elevated; that's OK, it just means the user may need to
  # re-run install.bat as Administrator for the firewall to match.
  try {
    netsh advfirewall firewall delete rule name="LessonTracker3002" | Out-Null
    netsh advfirewall firewall add rule name="LessonTracker3002" dir=in action=allow protocol=TCP localport=$newPort | Out-Null
  } catch {}

  [System.Windows.Forms.MessageBox]::Show("Port changed to $newPort and the server restarted. If other devices can't connect, you may need to re-run install.bat as Administrator so the firewall rule updates too.", "Settings saved", 0, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
})

$menuExit.Add_Click({
  Write-DexLog "=== Exit requested from tray menu ==="
  Stop-DexServer
  if ($script:ConsoleViewerProcess -and -not $script:ConsoleViewerProcess.HasExited) {
    try { $script:ConsoleViewerProcess.CloseMainWindow() | Out-Null } catch {}
  }
  $notifyIcon.Visible = $false
  [System.Windows.Forms.Application]::Exit()
})

# Safety net: make sure the server dies if the tray app is closed some
# other way (log off, task manager kill of this process, etc.). Runs in
# a detached engine-event scope that can't reliably see this script's own
# functions/variables (the same reason the OutputDataReceived handler
# above uses -MessageData instead of closures) - so this uses the same
# pattern: pass what it needs in via -MessageData, read it back via
# $Event.MessageData, self-contained rather than calling back into
# Stop-DexServer.
Register-EngineEvent PowerShell.Exiting -Action {
  try {
    $root = $Event.MessageData
    $cfgPath = Join-Path $root "data\config.json"
    $port = 3002
    if (Test-Path $cfgPath) {
      try { $port = [int]((Get-Content $cfgPath -Raw | ConvertFrom-Json).port) } catch {}
    }
    $lines = netstat -ano | Select-String ":$port " | Select-String "LISTENING"
    foreach ($line in $lines) {
      $parts = ($line.ToString() -split '\s+') | Where-Object { $_ -ne '' }
      Stop-Process -Id $parts[-1] -Force -ErrorAction SilentlyContinue
    }
  } catch {}
} -MessageData $AppRoot | Out-Null

[System.Windows.Forms.Application]::Run()

} catch {
  Write-DexLog "[FATAL] Tray app crashed: $_"
  try {
    [System.Windows.Forms.MessageBox]::Show(
      "DEX Labs ran into an unexpected error and needs to close:`n`n$_`n`nCheck logs.txt for details. You can still run the server directly with debug.bat while this gets fixed.",
      "DEX Labs - Fatal Error", 0, [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
  } catch {}
  try { Stop-DexServer } catch {}
}
