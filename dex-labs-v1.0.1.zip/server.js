// Log anything that would otherwise crash the process silently in the
// background (run-hidden.vbs redirects console output to logs.txt) -
// without this, a startup failure just looks like "nothing works" with
// zero clue why.
process.on('uncaughtException', (err) => {
  console.error('[FATAL] Uncaught exception:', err && err.stack || err);
});
process.on('unhandledRejection', (err) => {
  console.error('[FATAL] Unhandled promise rejection:', err && err.stack || err);
});

const express = require('express');
const path = require('path');
const os = require('os');

const airdropStore = require('./lib/airdrop-store');
const timersStore = require('./lib/timers-store');
const config = require('./lib/config-store');
const VERSION = require('./package.json').version;

// Port comes from data/config.json by default (settable via the tray
// app's Settings menu, and it survives updates since data/ is never
// touched by the update process). An explicit PORT env var always wins,
// for manual/advanced use (e.g. `set PORT=4000 && node server.js`).
const PORT = process.env.PORT || config.get().port || 3002;
const UPLOAD_ROOT = path.join(__dirname, 'uploads');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
// NOTE: this used to cache static files (index.html, app.js, css) in the
// browser for 1 hour (`maxAge: '1h'`). On an app that's actively being
// changed, that meant reloading the page could silently keep serving an
// OLD cached copy of the site for up to an hour with no visible sign
// anything was wrong - any fix made here wouldn't show up in the browser
// until the cache expired or someone did a hard refresh. Disabled.
app.use(express.static(path.join(__dirname, 'public'), { maxAge: 0, etag: true, lastModified: true }));

// Two independent feature areas, mounted side by side. They don't share
// any data - Lesson Tracker uses data/db.json + /uploads, AirDrop uses
// data/airdrop.json + /uploads-airdrop. Each is wrapped in its own
// try/catch at require+mount time so a problem loading ONE feature
// (e.g. a dependency that failed to install) can never take the other
// feature - or static file serving, or the whole server - down with it.
try {
  const lessonsRouter = require('./routes/lessons');
  app.use('/api', lessonsRouter(UPLOAD_ROOT));
  console.log('[OK] Lesson Tracker routes loaded.');
} catch (err) {
  console.error('[ERROR] Lesson Tracker routes failed to load - that feature will be unavailable:', err && err.stack || err);
  app.use('/api/subjects', (req, res) => res.status(500).json({ error: 'Lesson Tracker failed to start. Check logs.txt.' }));
}

try {
  const airdropRouter = require('./routes/airdrop');
  app.use('/api/airdrop', airdropRouter);
  console.log('[OK] AirDrop routes loaded.');
} catch (err) {
  console.error('[ERROR] AirDrop routes failed to load - that feature will be unavailable:', err && err.stack || err);
  app.use('/api/airdrop', (req, res) => res.status(500).json({ error: 'AirDrop failed to start. Check logs.txt.' }));
}

try {
  const scheduleRouter = require('./routes/schedule');
  app.use('/api/schedule', scheduleRouter);
  console.log('[OK] Daily Schedule routes loaded.');
} catch (err) {
  console.error('[ERROR] Daily Schedule routes failed to load - that feature will be unavailable:', err && err.stack || err);
  app.use('/api/schedule', (req, res) => res.status(500).json({ error: 'Daily Schedule failed to start. Check logs.txt.' }));
}

try {
  const timersRouter = require('./routes/timers');
  app.use('/api/timers', timersRouter);
  console.log('[OK] Timers routes loaded.');
} catch (err) {
  console.error('[ERROR] Timers routes failed to load - that feature will be unavailable:', err && err.stack || err);
  app.use('/api/timers', (req, res) => res.status(500).json({ error: 'Timers failed to start. Check logs.txt.' }));
}

// ---------- misc ----------
app.get('/api/server-info', (req, res) => {
  const nets = os.networkInterfaces();
  const addresses = [];
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) addresses.push(net.address);
    }
  }
  res.json({ port: PORT, addresses, version: VERSION });
});

app.get('/health', (req, res) => res.send('ok'));

const server = app.listen(PORT, '0.0.0.0', () => {
  console.log(`DEX Labs v${VERSION} running: http://localhost:${PORT}`);
  console.log(`  Subsystems: Lesson Tracker, AirDrop, Daily Schedule, Timers`);
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        console.log(`  On your WiFi/LAN:  http://${net.address}:${PORT}`);
      }
    }
  }
});

server.on('error', (err) => {
  console.error('[FATAL] Server failed to start:', err && err.stack || err);
  if (err && err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use - is the server already running? Try stop.bat first.`);
  }
});

// Don't let Node's default timeouts cut off very large (multi-GB) uploads
// on a slow LAN/WiFi connection.
server.requestTimeout = 0;
server.headersTimeout = 0;
server.timeout = 0;

// AirDrop files self-destruct after 1 hour. Sweep for expired ones once a
// minute, and once right at startup in case the server was off when some
// expired.
airdropStore.cleanupExpired().catch((e) => console.error('AirDrop startup cleanup error:', e));
setInterval(() => {
  airdropStore.cleanupExpired().catch((e) => console.error('AirDrop cleanup error:', e));
}, 60 * 1000).unref();

// Timers/alarms are server-authoritative - check every second for any
// that just expired (triggers the loud server-side beep) or are still
// ringing (keeps re-beeping until dismissed).
setInterval(() => {
  timersStore.tick().catch((e) => console.error('Timers tick error:', e));
}, 1000).unref();
