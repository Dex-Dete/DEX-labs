# Shared update logic - called by tray.ps1's Update menu AND by
# update.bat directly. Kept in one place so there's a single source of
# truth for the backup/extract/install steps rather than two copies that
# could drift apart.
#
# Does NOT stop or restart the server itself, and does NOT check version
# ordering - the caller (tray.ps1 or update.bat) is responsible for that,
# since they each have different ways of talking to the person running
# it. This script just does the mechanical part safely:
#   1. Back up data/uploads (ALWAYS - before touching anything else)
#   2. Extract the new files, but never overwrite data/uploads/backups
#   3. npm install
#
# Exit code 0 = success, non-zero = something went wrong (data is still
# safe either way, since the backup happens first).
param(
  [Parameter(Mandatory = $true)][string]$ZipPath
)

$AppRoot = $PSScriptRoot
$ErrorActionPreference = "Stop"

function Fail($msg) {
  Write-Host "[ERROR] $msg"
  exit 1
}

if (-not (Test-Path $ZipPath)) {
  Fail "Update file not found: $ZipPath"
}

Add-Type -AssemblyName System.IO.Compression.FileSystem

$timestamp = Get-Date -Format "yyyy-MM-dd_HHmmss"

# ---------- 1. Back up current data first, no matter what ----------
$backupDir = Join-Path $AppRoot "backups\backup-$timestamp"
try {
  New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
  foreach ($folder in @("data", "uploads", "uploads-airdrop")) {
    $src = Join-Path $AppRoot $folder
    if (Test-Path $src) {
      Copy-Item -Path $src -Destination (Join-Path $backupDir $folder) -Recurse -Force
    }
  }
  Write-Host "[OK] Backed up data/uploads to: $backupDir"
} catch {
  Fail "Could not back up existing data - stopping BEFORE touching any files, nothing was changed. Error: $_"
}

# ---------- 2. Extract the update to a temp staging folder ----------
$stagingDir = Join-Path $env:TEMP "dexlabs-update-staging-$timestamp"
try {
  if (Test-Path $stagingDir) { Remove-Item $stagingDir -Recurse -Force }
  [System.IO.Compression.ZipFile]::ExtractToDirectory($ZipPath, $stagingDir)
  Write-Host "[OK] Update extracted to staging area."
} catch {
  Fail "Could not extract the update zip. Your data backup is safe at $backupDir. Error: $_"
}

# ---------- 3. Copy new files over, preserving data/uploads/backups ----------
$excludeFolders = @("data", "uploads", "uploads-airdrop", "backups", "node_modules")
try {
  Get-ChildItem -Path $stagingDir | ForEach-Object {
    if ($excludeFolders -notcontains $_.Name) {
      $dest = Join-Path $AppRoot $_.Name
      if (Test-Path $dest) { Remove-Item $dest -Recurse -Force }
      Copy-Item -Path $_.FullName -Destination $dest -Recurse -Force
    }
  }
  Write-Host "[OK] Application files updated. Your data/uploads/backups were left untouched."
} catch {
  Fail "Something went wrong copying the new files in. Your data backup is safe at $backupDir - restore from there if this folder looks broken. Error: $_"
}
# ---------- 4. Install any new/changed dependencies ----------
Write-Host "Running npm install (needs internet)..."
Push-Location $AppRoot
try {
  npm install --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) {
    Write-Host "[WARNING] npm install exited with an error. The app files were updated, but some dependencies may be missing. Check the output above, then try running install.bat manually."
  } else {
    Write-Host "[OK] Dependencies installed."
  }
} finally {
  Pop-Location
}

# ---------- 5. Refresh the tray icon and Desktop/Start Menu shortcuts ----------
# This was a real gap fixed here: previously only install.bat created
# these, so anyone who updated via the tray's Update menu (or update.bat)
# instead of re-running install.bat never got them. Doing it here, as
# part of the shared update logic, means it happens every time regardless
# of which path was used to update.
try {
  $iconScript = Join-Path $AppRoot "generate-icon.ps1"
  if (Test-Path $iconScript) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $iconScript
  }
  $shortcutScript = Join-Path $AppRoot "create-shortcuts.ps1"
  if (Test-Path $shortcutScript) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $shortcutScript
  }
  Write-Host "[OK] Tray icon and shortcuts refreshed."
} catch {
  Write-Host "[WARNING] Could not refresh the icon/shortcuts - not critical, the app itself still works. Error: $_"
}

# ---------- 6. Clean up staging ----------
try { Remove-Item $stagingDir -Recurse -Force -ErrorAction SilentlyContinue } catch {}

Write-Host "=== Update complete. Backup kept at: $backupDir ==="
exit 0
