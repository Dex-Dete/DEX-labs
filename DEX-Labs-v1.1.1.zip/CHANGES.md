# DEX Labs v1.1.1 - Changes

Two changes, both inside the subsystem that used to be called "Timers"
(id `timers` in `lib/subsystems-registry.js` - **never renamed**, only
its display label changed):

## 1. Renamed "Timers" -> "Clock", added a Stopwatch menu

Still exactly **one subsystem** (explicit user requirement - not 3
separate ones). It now has **3 menus inside it**: Timer, Alarm,
Stopwatch - a segmented tab control at the top of the page
(`.clock-tabs` in `public/css/timers.css`), all served by the same
`public/js/timers.js` module and the same `routes/timers.js` router.

- **Timer** and **Alarm** are the exact same server-authoritative
  behavior as before (`lib/timers-store.js`, unchanged logic), just now
  each gets its own dedicated form/tab instead of one combined form with
  a kind-picker dropdown.
- **Stopwatch** (new) - start any number of independently named
  stopwatches (up to 10, same cap style as Timer/Alarm), Pause/Resume,
  Lap (keeps the last 50 laps per stopwatch), Reset, Remove. Server-
  backed (`lib/stopwatch-store.js`, `data/stopwatch.json`) so elapsed
  time survives a page reload or a server restart correctly - but unlike
  Timer/Alarm it needs no 1-second tick loop or beep, since there's
  nothing to expire or alert about; elapsed time is pure math off stored
  timestamps, computed fresh on every read.
- Deliberately reuses the **exact same ring/card visual language** as
  Timer/Alarm (explicit ask: "I like the animation that is there for
  alarms and timers, can you just make stopwatch like that too") - same
  `.timer-card`/`.timer-ring` markup and tokens. The ring can't count
  down to a known end point the way Timer/Alarm's does, so instead it
  draws a fixed ~30% arc that spins continuously via CSS while running
  (`sw-spin` in `public/css/timers.css`) and freezes in place when
  paused - same shape/family as the countdown ring, adapted for
  "elapsed with no known end."
- New routes, all under the same `/api/timers` mount (not a new
  server.js require/mount block - still one router file):
  `GET/POST /api/timers/stopwatches`,
  `POST /api/timers/stopwatches/:id/{pause,resume,lap,reset}`,
  `DELETE /api/timers/stopwatches/:id`.
- Navigation: `#/timers` = Timer (default), `#/timers/alarm` = Alarm,
  `#/timers/stopwatch` = Stopwatch - `public/js/app.js`'s router now
  passes `parts[1]` through to `Timers.render(subview)`.
- Not added to `GET /api/busy`'s idle check (unlike Timer/Alarm's
  `countActive()`) - a running stopwatch is just stored timestamps with
  no in-flight server work to protect, unlike an active timer's tick
  loop or a YouTube download's child process. Noted in
  `lib/stopwatch-store.js` in case a future session wonders why it's
  the odd one out.

## 2. Fixed: alarm/timer sound not audible over Bluetooth

**Reported bug**: when the server PC's default audio output was a
Bluetooth speaker/headset, the alarm went completely silent - worked
fine on the PC's built-in speakers.

**Root cause**: the server-side beep (`ringServerBeep()` in
`lib/timers-store.js`) called PowerShell's built-in `[console]::beep()`,
which drives the low-level Win32 `Beep()` API. That API is a legacy
motherboard-speaker primitive - it does NOT reliably go through the
normal Windows audio mixer / default-playback-device selection the way
real audio playback does, so it can be silent on Bluetooth (and some
USB) outputs while still working on built-in speakers.

**Fix**: `ringServerBeep()` now synthesizes a short tone as a real
in-memory WAV file and plays it with .NET's `System.Media.SoundPlayer`,
which goes through the normal multimedia audio stack and therefore
follows whatever the current default playback device actually is -
Bluetooth included. Still zero extra npm/native dependencies
(`System.Media`/`System.IO` are built into .NET, same "nothing extra to
install" philosophy as the rest of this project). If `SoundPlayer` ever
throws for some reason (e.g. no audio device present at all), the same
PowerShell script falls back to the old `[console]::beep()` inside a
`try/catch`, so this can't regress to total silence versus before.

**Not tested on real Windows hardware** - same caveat as everything
else in this project's audio/PowerShell path (see "the one area that
could NOT be tested" in `PROJECT_BRIEFING.md`). If the user reports it's
still silent over Bluetooth after this update, get the exact `logs.txt`
output from a ringing alarm next.

---

# DEX Labs v1.1.0 - Changes

v1.1.0 merges two parallel change sets that were built in separate Claude
sessions and merged by a third:

- **Part 1** ("v1.0.7" from its own session): a new, independent
  subsystem - **⬇ YouTube Downloader**.
- **Part 2** ("v1.0.5 Part 2"): a crash-restart watchdog, a forced
  first-run AirDrop setup flow, an update-announcement banner, a
  **subsystem show/hide menu** (built as a generic registry so it scales
  past the ~30 subsystems planned down the road), and an update-backup
  fix.
- **This merge** (session 3): wired Part 1's YouTube Downloader into Part
  2's subsystem registry/hide-menu system, resolved the few real file
  collisions, and closed one integration gap the two sessions couldn't
  have seen coming from either side alone (see "Merge work" below).

Version bumped straight to **1.1.0** (rather than 1.0.5) to reflect that
this is the combined release both parts were building toward.

---

## Part 1 - YouTube Downloader (new subsystem)

- Paste a YouTube video link, see real quality options (Max / Medium /
  Lowest / Audio-only) with accurate file sizes pulled straight from the
  video, pick one, and download it to this PC.
- Drives [`yt-dlp`](https://github.com/yt-dlp/yt-dlp) directly as a child
  process (not a scraping library) - the same tool most of the
  self-hosting/archiving community relies on because it's actively
  maintained against YouTube's frequent changes.
- **`yt-dlp` sets itself up automatically** (checks PATH, then this app's
  own `tools-youtube/` folder, downloads it itself if missing - starts in
  the background at server startup) and **keeps itself updated** via its
  own self-update check, run periodically for as long as the server is up.
- **`ffmpeg` does NOT auto-download by default** - place `ffmpeg.exe` /
  `ffprobe.exe` in `tools-youtube/` yourself; detected automatically, no
  restart needed. (Auto-download exists and can be re-enabled via
  `AUTO_DOWNLOAD_FFMPEG` in `lib/ytdownload-store.js`, but proved
  unreliable against real third-party hosts, so it ships off.)
- Higher resolutions YouTube only serves as separate video/audio streams
  are merged with `ffmpeg` automatically.
- Downloads land in `downloads-youtube/` and are swept away after 24
  hours if unclaimed - independent of AirDrop's own 1-hour rule, since
  this is a personal download, not a shared drop.
- Built independently - own store (`lib/ytdownload-store.js`), own route
  (`routes/ytdownload.js`), own frontend module (`public/js/ytdownload.js`
  + `public/css/ytdownload.css`) - no cross-references into any other
  subsystem's data, per this project's usual convention.

## Part 2, Round 1 - watchdog, forced AirDrop setup, update banner

1. **Crash-restart watchdog** in `tray.ps1` (`Invoke-DexWatchdogCheck`,
   its own 5-second `System.Windows.Forms.Timer`): if the server process
   isn't running, restart it - unless an update is legitimately in
   progress, in which case it defers, but only for up to 15 seconds (past
   that, assumes the update is stuck/finished and restarts anyway).
2. **Forced first-run setup**: AirDrop's max-usage-GB and save-location
   are now live-configurable (`lib/config-store.js`'s `setupComplete`,
   `airdropMaxUsageGB`, `airdropSaveLocation`) instead of hardcoded, via a
   new Settings page on the website and a new prompt in the tray's
   Settings menu. Until `setupComplete` is true, the website redirects
   every route to Settings first. `lib/airdrop-store.js` now reads these
   live on every call, so a change takes effect with no restart.
3. **Update-announcement banner**: shows the latest GitHub release's
   notes once per new version, with a link and an OK button, via new
   `GET /api/settings/updates/latest` / `POST /api/settings/updates/ack`
   endpoints (10-minute server-side cache on the GitHub call).

## Part 2, Round 2 - subsystem show/hide menu, backup fix

4. **Subsystem show/hide menu** (website Settings page + tray Settings
   menu): hide any subsystem from the nav without deleting anything, and
   choose what loads first if the current default gets hidden. Built as
   a generic registry (`lib/subsystems-registry.js`) - listing `id`,
   `label`, `navLabel`, `hash`, `hideable` per subsystem - plus a
   `window.DexSubsystems` self-registration convention on the frontend,
   specifically so adding subsystem #5, #6, ... #30+ later needs no
   `app.js` edits. Hidden subsystems are blocked from direct hash
   navigation too (typing/following a link to a hidden one's URL bounces
   to `#/`), not just hidden from the nav buttons. Server is the source
   of truth (`GET/PUT /api/settings/subsystems`, with guards against
   hiding every subsystem and against an invalid landing choice); the
   frontend mirrors the same fallback logic for a smoother UI.
5. **Backup fix** in `apply-update.ps1`: a gap in Round 1's own AirDrop
   work - a custom save location wasn't being backed up before an
   update (only the default `uploads-airdrop/` was). Now the backup step
   also reads `airdropSaveLocation` from config and backs it up under
   `uploads-airdrop-custom-location/` if set, non-fatally if that
   sub-step itself fails.

---

## Merge work (this session)

Per `WHAT-TO-DO-part3.md`'s merge plan: started from Part 2 (the more
invasive change set - it reworked `app.js`'s nav/router) as the base,
copied Part 1's new files in on top, then did the one real piece of
integration work:

- **`lib/subsystems-registry.js`** - added the YouTube Downloader entry:
  `{ id: 'ytdownload', label: 'YouTube Downloader', navLabel: '⬇ YT Download', hash: '#/ytdownload', hideable: true }`,
  matching the `id`/hash Part 1's own `app.js` already used internally
  before the merge.
- **`public/js/ytdownload.js`** - added the
  `window.DexSubsystems['ytdownload'] = { render }` self-registration
  line (alongside the existing `window.YTDownload` export, left in place
  in case anything else references it). `render()` already matched the
  standard self-contained-module shape (same as `airdrop.js`/
  `schedule.js`/`timers.js`), so no changes were needed inside it.
- **`public/index.html`** - added `ytdownload.css`'s `<link>` and
  `ytdownload.js`'s `<script>` tag (before `app.js`, so it's registered
  by the time `route()` runs). No nav `<button>` needed - Part 1's own
  hardcoded one was never carried over, since Part 2's dynamic
  `#nav-links` renders it automatically from the registry now that step
  1 above is done.
- **`server.js`** - mounted `routes/ytdownload.js` at `/api/ytdownload`
  in its own try/catch (same isolation pattern as every other
  subsystem); added the startup calls for `ensureTools()` (background
  yt-dlp/ffmpeg setup at boot) and the periodic self-update/cleanup
  intervals Part 1's server.js had; added "YouTube Downloader" to the
  startup subsystems log line.
- **No changes needed to `app.js`'s `route()`** - confirmed its existing
  generic `window.DexSubsystems` fallback picks up `ytdownload`
  automatically with the registry entry above in place, exactly as
  `WHAT-TO-DO-part3.md` predicted.
- **`package.json`** - both parts already had the exact same
  `dependencies` (Part 1 didn't add any new npm packages - `yt-dlp` is
  driven as an external binary/child-process, not an npm library), so no
  dependency merge was actually needed. Version bumped to `1.1.0` and
  `package-lock.json` regenerated cleanly via `npm install` rather than
  hand-merged.
- **`lib/config-store.js`** - Part 1 made no additions here, so Part 2's
  version was taken as-is, no merge needed.
- **`lib/airdrop-store.js` / `routes/airdrop.js` / `db.js`** - Part 1
  didn't touch AirDrop or the Lesson Tracker DB at all (confirmed via
  diff against Part 2's versions - byte-identical), so no merge conflict
  existed here either; despite the file overlap in both zips, Part 1's
  YouTube work really was independent as described.
- **`tray.ps1`** - likewise confirmed byte-identical in substance between
  Part 1 and Part 2 aside from Part 2's own watchdog/settings-dialog
  additions (Part 1's copy had no YouTube-specific tray logic to merge
  in), so Part 2's version was taken as the base with nothing to
  reconcile.

### One integration gap closed: `GET /api/busy` didn't know about downloads

`WHAT-TO-DO-part3.md` flagged this as worth checking rather than telling
us the answer, since neither part could see it from its own side: the
tray's watchdog/auto-update logic avoids restarting the server while
`GET /api/busy` reports anything in flight - and before this merge, that
endpoint only checked file uploads and running timers, with no way to
know a YouTube download was mid-transfer. Fixed as part of the merge:

- **`lib/ytdownload-store.js`** - added `countActive()` (counts jobs with
  status `queued`/`downloading`), mirroring `lib/timers-store.js`'s
  existing `countActive()`.
- **`server.js`** - `GET /api/busy` now also calls this and includes a
  `downloadsActive` count / a `"N YouTube download(s) in progress"`
  reason string alongside the existing upload/timer checks.

This means the crash-restart watchdog and the background auto-updater
will now correctly wait out an in-progress YouTube download the same way
they already wait out a running timer or an in-progress upload, instead
of only knowing about two of the app's three kinds of "don't restart me
right now" state.

### File collisions - actual result

Per the merge plan's predictions in `WHAT-TO-DO-part3.md`, `server.js`
and `public/index.html` were the only files with real overlapping edits
to reconcile (handled above); `package.json` only needed a version bump
since dependencies already matched; `lib/config-store.js` needed no
merge since only Part 2 touched it. No unexpected collisions turned up.

## Testing performed (this session)

Following this project's established methodology: ran the actual merged
server as a subprocess and hit it with real HTTP requests, plus a
headless-browser (`jsdom`) pass over the real frontend since earlier
sessions had no browser available at all.

- **`npm install`** completed cleanly with a freshly regenerated
  `package-lock.json`; server boots with `[OK]` logged for all six
  subsystems, including `[OK] YouTube Downloader routes loaded.`
- **Confirmed working, live**: `GET /api/settings/subsystems` includes
  the new `ytdownload` entry; `PUT /api/settings/subsystems` can hide/
  unhide it and the change persists on re-fetch; `GET /api/busy` returns
  the new `downloadsActive` field; `GET /api/ytdownload/status` responds
  correctly (and confirmed `yt-dlp` really does auto-download itself on
  first boot, exactly as documented - the one failure seen in this
  sandbox was the downloaded binary not executing, which looks like a
  sandbox/architecture limitation rather than a code issue, since the
  download-and-detect logic itself worked correctly).
- **Confirmed working, live, via `jsdom`** (a real browser DOM, not a
  Node/curl simulation) against the real running server:
  - The dynamically-built nav includes a "⬇ YT Download" button with
    nothing hidden.
  - Navigating directly to `#/ytdownload` renders the real YouTube
    Downloader page (`<h2>YouTube Downloader</h2>`), not a placeholder.
  - After hiding `ytdownload` via the Settings API, the nav button
    disappears **and** navigating directly to `#/ytdownload` bounces back
    to `#/` - both halves of the hide behavior Part 2 built, confirmed
    working automatically for Part 1's subsystem with no `app.js` changes.
- **Not testable here (no Windows/PowerShell)**: everything in
  `tray.ps1` remains unverified on real Windows, same caveat as both
  parts already carried - this is still the single highest-value thing
  left to test before fully trusting v1.1.0, especially the watchdog and
  `Show-DexSubsystemsDialog`.

## Known remaining gaps

- `tray.ps1` (all of it, across both parts) has never run on real
  Windows/PowerShell - see above.
- The GitHub-release-notes banner's live network call was previously
  confirmed via `curl` outside Node but rate-limited when called from
  Node itself in Part 2's own sandbox (see "Part 2, Round 1" above) -
  worth a real check post-merge if possible, though the graceful-failure
  path was confirmed working either way.
