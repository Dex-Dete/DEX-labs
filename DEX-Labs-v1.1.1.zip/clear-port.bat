@echo off
rem Shared helper: kills anything on the configured port (and any
rem tray.ps1 instance). Called by install.bat/start.bat/debug.bat before
rem launching, so a leftover process from a previous crash/session never
rem causes "address already in use" on the next start.
rem Reads the port from data\config.json (set via the tray's Settings
rem menu) - falls back to 3002 if that file doesn't exist yet.
set "DEXPORT=3002"
if exist "data\config.json" (
  for /f "usebackq delims=" %%p in (`powershell -NoProfile -Command "try { (Get-Content 'data\config.json' -Raw | ConvertFrom-Json).port } catch { 3002 }"`) do set "DEXPORT=%%p"
)
if "%DEXPORT%"=="" set "DEXPORT=3002"

for /f "tokens=5" %%p in ('netstat -ano ^| findstr :%DEXPORT% ^| findstr LISTENING') do (
  taskkill /F /PID %%p >nul 2>nul
)
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='powershell.exe'\" | Where-Object { $_.CommandLine -like '*tray.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>nul
